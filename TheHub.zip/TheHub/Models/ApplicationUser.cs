﻿using AspNet.Identity.SQLite;

namespace TheHub.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}